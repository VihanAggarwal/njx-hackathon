# DUALMIND — head-to-head leaderboard (real measured)

mode=live · n=48 · seed=42 · real LLMail-Inject data · lower ASR/FPR/ECE better, higher TPR/F1/AUC better

| Defense | ASR | FPR | TPR | F1 | AUC | ECE |
|---|---|---|---|---|---|---|
| DUALMIND | 0.000 | 0.000 | 1.000 | 1.000 | 1.000 | 0.086 |
| Lakera Guard (commercial) | 0.000 | 0.125 | 1.000 | 0.941 | 0.938 | 0.062 |
| NeMo self-check * | 0.417 | 0.000 | 0.583 | 0.737 | 0.977 | 0.202 |
| Vanilla LLM self-check | 0.542 | 0.000 | 0.458 | 0.629 | 0.932 | 0.261 |
| Regex / keyword filter | 0.583 | 0.000 | 0.417 | 0.588 | 0.708 | 0.349 |
| ProtectAI deberta-v3 v2 | 0.583 | 0.000 | 0.417 | 0.588 | 0.890 | 0.292 |
| Meta Prompt-Guard-2 86M | 0.875 | 0.000 | 0.125 | 0.222 | 0.760 | 0.436 |
